const LocalStrategy = require('passport-local').Strategy;
const bcrypt = require('bcryptjs');
module.exports = function (passport) {
    passport.use('local-login',
        new LocalStrategy({ usernameField: "email", passwordField: "password" }, (email, password, done) => {
            db.collection('myProfile').findOne({ email: email })
                .then(data => {
                    // console.log(data)
                    if (!data) {
                        return done(null, false, { message: "not" });
                    }
                    bcrypt.compare(password, data.password, (err, isMatch) => {
                        if (err) throw err;
                        if (isMatch) {
                            return done(null, data, { message: "success" });
                        } else {
                            return done(null, false, { message: "incorrect" });
                        }
                    });
                })
                .catch(err => console.log(err));
        })
    )

    ////////////////////////SIGNUP\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\
    passport.use('local-signup',
        new LocalStrategy({ usernameField: "email", passwordField: "password", passReqToCallback: true }, (req, email, password, done) => {
            db.collection('myProfile').findOne({ email: email })
                .then(data => {
                    if (data) {
                        return done(null, false, { message: "exists" });
                    } else {
                        bcrypt.genSalt(10, (err, salt) => bcrypt.hash(password, salt, (error, hash) => {
                            if (error) throw error;
                            db.collection('myProfile').insertOne({
                                name: req.body.name,
                                email: email,
                                password: hash,
                                phone: req.body.contact,
                            }, (err, data) => {
                                if (err) throw err;
                                return done(null, data.ops[0], { message: "success" });
                            });
                        }));
                    }
                })
                .catch(err => {
                    console.log(err);
                });
        })
    )
    passport.serializeUser((user, done) => {
        done(null, user);
    });
    passport.deserializeUser((user, done) => {
        done(null, user);
    });

}