var express = require('express');
const { ensureAuthenticated } = require("../config/auth");
var router = express.Router();
var { loginUser, signUp, RegisterUser, dashboard,logout } = require('../controller/index.controller')
/* GET home page. */
router.get('/', function (req, res, next) {
  // console.log(res.clearCookie('sellersInfo'))
  // console.log(req)
  res.render('index', { title: 'Express' });
});
router.post('/loginUser', loginUser)
router.get('/user/signup', signUp)
router.post('/RegisterUser', RegisterUser)
router.get('/dashboard', ensureAuthenticated, dashboard)
router.get('/logout',logout)
module.exports = router;
