const passport = require('passport');
const bcrypt = require('bcryptjs');
module.exports = {
    loginUser: (req, res, next) => {
        passport.authenticate('local-login', function (err, user, info) {
            if (err) { return res.send(err); }
            if (!user) { return res.send(info); }
            req.logIn(user, async function (err) {
                return res.send({ message: "success" });
            });
        })(req, res, next);
    },
    signUp: (req, res) => {
        res.render('signup')
    },
    RegisterUser: (req, res, next) => {
        passport.authenticate('local-signup', function (err, user, info) {
            console.log(info)
            if (err) { return res.send({ message: "success1" }); }
            if (!user) { return res.send({ message: "exists" }); }
            req.logIn(user, async function (err) {
                // if (err) { return res.send({ message: "success" }); }
                return res.send({ message: "success" });
            });
        })(req, res, next);
    },
    dashboard: (req, res) => {
        console.log(req.user)
        res.render('dashboard', {
            req
        })
    },
    logout : (req,res)=>{
        req.logout();
        res.redirect('/');
    }
}