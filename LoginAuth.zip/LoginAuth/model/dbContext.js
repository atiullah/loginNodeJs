var MongoClient = require('mongodb').MongoClient
MongoClient.connect('mongodb://localhost:27017/',{ useUnifiedTopology: true } ,function (err, client) {
    if (err) { console.error(err) }
    db = client.db('Mydb') // once connected, assign the connection to the global variable
    db.global = db
})